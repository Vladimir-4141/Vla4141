from fastapi import FastAPI, APIRouter, HTTPException, Query
from dotenv import load_dotenv
from starlette.middleware.cors import CORSMiddleware
from motor.motor_asyncio import AsyncIOMotorClient
import os
import logging
from pathlib import Path
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional
import uuid
from datetime import datetime, timezone

ROOT_DIR = Path(__file__).parent
load_dotenv(ROOT_DIR / '.env')

# MongoDB connection
mongo_url = os.environ['MONGO_URL']
client = AsyncIOMotorClient(mongo_url)
db = client[os.environ['DB_NAME']]

# Create the main app without a prefix
app = FastAPI()

# Create a router with the /api prefix
api_router = APIRouter(prefix="/api")


# Define Models
class Program(BaseModel):
    name: str
    description: str
    form: Optional[str] = None
    budget_places: Optional[int] = None
    paid_places: Optional[int] = None
    cost: Optional[str] = None


class Contact(BaseModel):
    address: str
    phone: Optional[str] = None
    email: Optional[str] = None
    website: Optional[str] = None


class Institution(BaseModel):
    model_config = ConfigDict(extra="ignore")
    
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    name: str
    short_name: str
    type: str
    director: Optional[str] = None
    description: str
    logo: Optional[str] = None
    image: Optional[str] = None
    programs: List[Program] = []
    contact: Contact
    coordinates: dict
    employment_partners: List[str] = []
    extracurricular: List[str] = []
    admission_dates: Optional[dict] = None
    documents_required: List[str] = []


class InstitutionCreate(BaseModel):
    name: str
    short_name: str
    type: str
    director: Optional[str] = None
    description: str
    logo: Optional[str] = None
    image: Optional[str] = None
    programs: List[Program] = []
    contact: Contact
    coordinates: dict
    employment_partners: List[str] = []
    extracurricular: List[str] = []
    admission_dates: Optional[dict] = None
    documents_required: List[str] = []


class InstitutionListItem(BaseModel):
    model_config = ConfigDict(extra="ignore")
    
    id: str
    name: str
    short_name: str
    type: str
    description: str
    logo: Optional[str] = None
    image: Optional[str] = None
    contact: Contact
    coordinates: dict
    programs_count: int


def institution_to_list_item(doc):
    return {
        "id": doc["id"],
        "name": doc["name"],
        "short_name": doc["short_name"],
        "type": doc["type"],
        "description": doc["description"],
        "logo": doc.get("logo"),
        "image": doc.get("image"),
        "contact": doc["contact"],
        "coordinates": doc["coordinates"],
        "programs_count": len(doc.get("programs", []))
    }


@api_router.get("/")
async def root():
    return {"message": "Профнавигатор абитуриента Камчатского края API"}


@api_router.get("/institutions", response_model=List[InstitutionListItem])
async def get_institutions(
    type: Optional[str] = Query(None, description="Filter by type: 'spo' or 'vo'"),
    search: Optional[str] = Query(None, description="Search by name")
):
    query = {}
    if type:
        query["type"] = type
    if search:
        query["name"] = {"$regex": search, "$options": "i"}
    
    institutions = await db.institutions.find(query, {"_id": 0}).to_list(100)
    return [institution_to_list_item(inst) for inst in institutions]


@api_router.get("/institutions/{institution_id}", response_model=Institution)
async def get_institution(institution_id: str):
    institution = await db.institutions.find_one({"id": institution_id}, {"_id": 0})
    if not institution:
        raise HTTPException(status_code=404, detail="Institution not found")
    return institution


@api_router.post("/institutions", response_model=Institution)
async def create_institution(input: InstitutionCreate):
    institution_dict = input.model_dump()
    institution_obj = Institution(**institution_dict)
    doc = institution_obj.model_dump()
    await db.institutions.insert_one(doc)
    return institution_obj


@api_router.get("/map-data")
async def get_map_data():
    institutions = await db.institutions.find(
        {},
        {"_id": 0, "id": 1, "name": 1, "short_name": 1, "type": 1, "coordinates": 1, "contact": 1}
    ).to_list(100)
    return institutions


@api_router.post("/reseed-data")
async def reseed_data():
    """Delete all data and reseed"""
    await db.institutions.delete_many({})
    return await seed_data_internal()


@api_router.post("/seed-data")
async def seed_data():
    count = await db.institutions.count_documents({})
    if count > 0:
        return {"message": f"Data already exists ({count} institutions)"}
    return await seed_data_internal()


async def seed_data_internal():
    institutions_data = [
        # ========== СПО (14 учреждений) ==========
        {
            "id": "kmet",
            "name": "КГПОАУ Камчатский морской энергетический техникум",
            "short_name": "КГПОАУ «КМЭТ»",
            "type": "spo",
            "director": "Петрова Любовь Юрьевна",
            "description": "Краевое государственное профессиональное образовательное автономное учреждение осуществляет образовательную деятельность в части подготовки членов экипажей морских судов.",
            "logo": "https://kamchatkairo.ru/images/profnavigator/2025/kmet/logo.jpeg",
            "image": "https://images.unsplash.com/photo-1569263979104-865ab7cd8d13?w=800",
            "programs": [
                {"name": "Судовождение", "description": "Подготовка специалистов по управлению судном", "form": "очная", "budget_places": 25},
                {"name": "Эксплуатация судовых энергетических установок", "description": "Техническое обслуживание судового оборудования", "form": "очная", "budget_places": 25},
                {"name": "Электрооборудование и автоматика судов", "description": "Обслуживание электрических систем судна", "form": "очная", "budget_places": 25},
                {"name": "Теплоснабжение и теплотехническое оборудование", "description": "Эксплуатация теплотехнического оборудования", "form": "очная", "budget_places": 25}
            ],
            "contact": {
                "address": "г. Петропавловск-Камчатский, ул. Чубарова, д. 1",
                "phone": "+7 (4152) 41-23-45",
                "email": "kmet@edu.kamchatka.ru",
                "website": "https://kmet41.ru"
            },
            "coordinates": {"lat": 53.0167, "lng": 158.6500},
            "employment_partners": ["Камчатское морское пароходство", "Рыболовецкие компании Камчатки"],
            "extracurricular": ["Морской клуб", "Спортивные секции", "Волонтерское движение"],
            "documents_required": ["Аттестат", "Паспорт", "СНИЛС", "Медицинская справка 086/У", "Фотографии 3x4"]
        },
        {
            "id": "kpk",
            "name": "КГПОБУ Камчатский педагогический колледж",
            "short_name": "КГПОБУ «КПК»",
            "type": "spo",
            "director": "Директор педагогического колледжа",
            "description": "Краевое государственное профессиональное образовательное бюджетное учреждение — ведущее учреждение по подготовке педагогических кадров для школ и детских садов Камчатского края.",
            "logo": "https://kamchatkairo.ru/images/profnavigator/2025/kpk/logo.png",
            "image": "https://images.unsplash.com/photo-1509062522246-3755977927d7?w=800",
            "programs": [
                {"name": "Преподавание в начальных классах", "description": "Подготовка учителей начальных классов", "form": "очная", "budget_places": 50},
                {"name": "Дошкольное образование", "description": "Подготовка воспитателей детских садов", "form": "очная", "budget_places": 50},
                {"name": "Физическая культура", "description": "Подготовка учителей физкультуры", "form": "очная", "budget_places": 25}
            ],
            "contact": {
                "address": "г. Петропавловск-Камчатский, ул. Пограничная, д. 31",
                "phone": "+7 (4152) 42-15-67",
                "email": "kpk@edu.kamchatka.ru",
                "website": "https://kpk41.ru"
            },
            "coordinates": {"lat": 53.0240, "lng": 158.6430},
            "employment_partners": ["Школы Камчатского края", "Детские сады региона"],
            "extracurricular": ["Педагогический отряд", "Творческие студии", "Спортивные секции"],
            "documents_required": ["Аттестат", "Паспорт", "СНИЛС", "Медицинская справка 086/У", "Фотографии 3x4"]
        },
        {
            "id": "kkts",
            "name": "КГПОАУ Камчатский колледж технологии и сервиса",
            "short_name": "КГПОАУ «ККТС»",
            "type": "spo",
            "director": "Директор колледжа",
            "description": "Краевое государственное профессиональное образовательное автономное учреждение готовит специалистов в сфере общественного питания, торговли, парикмахерского искусства и туризма.",
            "logo": "https://kamchatkairo.ru/images/profnavigator/2025/kkts/logo.png",
            "image": "https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=800",
            "programs": [
                {"name": "Поварское и кондитерское дело", "description": "Подготовка поваров и кондитеров", "form": "очная", "budget_places": 50},
                {"name": "Парикмахерское искусство", "description": "Подготовка парикмахеров-стилистов", "form": "очная", "budget_places": 25},
                {"name": "Туризм и гостиничное дело", "description": "Работа в сфере туризма и гостеприимства", "form": "очная", "budget_places": 25}
            ],
            "contact": {
                "address": "г. Петропавловск-Камчатский, ул. Ленинградская, д. 47",
                "phone": "+7 (4152) 42-33-44",
                "email": "kkts@edu.kamchatka.ru",
                "website": "https://kkts41.ru"
            },
            "coordinates": {"lat": 53.0190, "lng": 158.6580},
            "employment_partners": ["Рестораны и кафе Камчатки", "Гостиницы региона", "Туристические компании"],
            "extracurricular": ["Кулинарный клуб", "Студия красоты", "Туристический клуб"],
            "documents_required": ["Аттестат", "Паспорт", "СНИЛС", "Медицинская справка 086/У", "Фотографии 3x4"]
        },
        {
            "id": "kit",
            "name": "КГПОБУ Камчатский индустриальный техникум",
            "short_name": "КГПОБУ «КИТ»",
            "type": "spo",
            "director": "Директор техникума",
            "description": "Краевое государственное профессиональное образовательное бюджетное учреждение готовит специалистов для промышленных предприятий региона в области машиностроения и электротехники.",
            "logo": "https://kamchatkairo.ru/images/profnavigator/2025/kit/logo.png",
            "image": "https://images.unsplash.com/photo-1581091226825-a6a2a5aee158?w=800",
            "programs": [
                {"name": "Техническое обслуживание и ремонт автомобилей", "description": "Подготовка автомехаников", "form": "очная", "budget_places": 50},
                {"name": "Сварочное производство", "description": "Подготовка сварщиков", "form": "очная", "budget_places": 25},
                {"name": "Электромонтаж", "description": "Монтаж электрооборудования", "form": "очная", "budget_places": 25}
            ],
            "contact": {
                "address": "г. Петропавловск-Камчатский, ул. Индустриальная, д. 15",
                "phone": "+7 (4152) 41-55-66",
                "email": "kit@edu.kamchatka.ru",
                "website": "https://kit41.ru"
            },
            "coordinates": {"lat": 53.0310, "lng": 158.6380},
            "employment_partners": ["Автосервисы Камчатки", "Промышленные предприятия", "Строительные компании"],
            "extracurricular": ["Технический кружок", "Автоклуб", "Спортивные секции"],
            "documents_required": ["Аттестат", "Паспорт", "СНИЛС", "Медицинская справка 086/У", "Фотографии 3x4"]
        },
        {
            "id": "kki",
            "name": "КГБПОУ Камчатский колледж искусств",
            "short_name": "КГБПОУ «ККИ»",
            "type": "spo",
            "director": "Директор колледжа искусств",
            "description": "Краевое государственное бюджетное профессиональное образовательное учреждение — единственное в регионе учебное заведение, готовящее специалистов в области музыки, хореографии и изобразительного искусства.",
            "logo": "https://kamchatkairo.ru/images/profnavigator/2025/kki/logo.png",
            "image": "https://images.unsplash.com/photo-1507838153414-b4b713384a76?w=800",
            "programs": [
                {"name": "Музыкальное искусство", "description": "Подготовка музыкантов-исполнителей", "form": "очная", "budget_places": 20},
                {"name": "Хореографическое искусство", "description": "Подготовка артистов балета и танцоров", "form": "очная", "budget_places": 15},
                {"name": "Дизайн", "description": "Графический и средовой дизайн", "form": "очная", "budget_places": 20},
                {"name": "Декоративно-прикладное искусство", "description": "Традиционные ремёсла народов Камчатки", "form": "очная", "budget_places": 15}
            ],
            "contact": {
                "address": "г. Петропавловск-Камчатский, ул. Советская, д. 28",
                "phone": "+7 (4152) 42-77-88",
                "email": "kki@edu.kamchatka.ru",
                "website": "https://kki41.ru"
            },
            "coordinates": {"lat": 53.0190, "lng": 158.6480},
            "employment_partners": ["Театры Камчатки", "Музыкальные школы", "Дома культуры"],
            "extracurricular": ["Студенческий театр", "Концертный ансамбль", "Художественная мастерская"],
            "documents_required": ["Аттестат", "Паспорт", "СНИЛС", "Медицинская справка 086/У", "Фотографии 3x4", "Портфолио"]
        },
        {
            "id": "ksht",
            "name": "КГПОБУ Камчатский сельскохозяйственный техникум",
            "short_name": "КГПОБУ «КСхТ»",
            "type": "spo",
            "director": "Директор техникума",
            "description": "Краевое государственное профессиональное образовательное бюджетное учреждение готовит специалистов для агропромышленного комплекса Камчатского края.",
            "logo": "https://kamchatkairo.ru/images/profnavigator/2025/ksht/logo.png",
            "image": "https://images.unsplash.com/photo-1500937386664-56d1dfef3854?w=800",
            "programs": [
                {"name": "Агрономия", "description": "Выращивание сельскохозяйственных культур", "form": "очная", "budget_places": 25},
                {"name": "Ветеринария", "description": "Лечение и профилактика болезней животных", "form": "очная", "budget_places": 25},
                {"name": "Механизация сельского хозяйства", "description": "Обслуживание сельхозтехники", "form": "очная", "budget_places": 25},
                {"name": "Кинология", "description": "Разведение и дрессировка собак", "form": "очная", "budget_places": 15}
            ],
            "contact": {
                "address": "г. Елизово, ул. Завойко, д. 5",
                "phone": "+7 (41531) 6-22-33",
                "email": "ksht@edu.kamchatka.ru",
                "website": "https://ksht41.ru"
            },
            "coordinates": {"lat": 53.1870, "lng": 158.3800},
            "employment_partners": ["Сельскохозяйственные предприятия", "Ветеринарные клиники", "Питомники"],
            "extracurricular": ["Агроклуб", "Кинологический кружок", "Экологический отряд"],
            "documents_required": ["Аттестат", "Паспорт", "СНИЛС", "Медицинская справка 086/У", "Фотографии 3x4"]
        },
        {
            "id": "kmk",
            "name": "ГБПОУ КК Камчатский медицинский колледж",
            "short_name": "ГБПОУ КК «КМК»",
            "type": "spo",
            "director": "Директор медицинского колледжа",
            "description": "Государственное бюджетное профессиональное образовательное учреждение Камчатского края — главный поставщик медицинских кадров для учреждений здравоохранения региона.",
            "logo": "https://kamchatkairo.ru/images/profnavigator/2025/kmk/logo.png",
            "image": "https://images.unsplash.com/photo-1576091160399-112ba8d25d1f?w=800",
            "programs": [
                {"name": "Сестринское дело", "description": "Подготовка медицинских сестёр", "form": "очная", "budget_places": 60},
                {"name": "Лечебное дело", "description": "Подготовка фельдшеров", "form": "очная", "budget_places": 40},
                {"name": "Фармация", "description": "Подготовка фармацевтов", "form": "очная", "budget_places": 25},
                {"name": "Стоматология ортопедическая", "description": "Изготовление зубных протезов", "form": "очная", "budget_places": 15}
            ],
            "contact": {
                "address": "г. Петропавловск-Камчатский, ул. Ленинская, д. 112",
                "phone": "+7 (4152) 42-88-99",
                "email": "kmk@edu.kamchatka.ru",
                "website": "https://kmk41.ru"
            },
            "coordinates": {"lat": 53.0120, "lng": 158.6590},
            "employment_partners": ["Краевая больница", "Поликлиники", "Аптечные сети"],
            "extracurricular": ["Волонтёры-медики", "Научное общество", "Спортивные секции"],
            "documents_required": ["Аттестат", "Паспорт", "СНИЛС", "Медицинская справка 086/У", "Фотографии 3x4", "Справка о прививках"]
        },
        {
            "id": "palan",
            "name": "КГПОБУ Паланский колледж",
            "short_name": "КГПОБУ «ПК»",
            "type": "spo",
            "director": "Директор колледжа",
            "description": "Краевое государственное профессиональное образовательное бюджетное учреждение — единственное учреждение СПО на севере Камчатского края, обеспечивающее кадрами отдалённые районы региона.",
            "logo": "https://kamchatkairo.ru/images/profnavigator/2025/palan/logo.png",
            "image": "https://images.unsplash.com/photo-1523050854058-8df90110c9f1?w=800",
            "programs": [
                {"name": "Преподавание в начальных классах", "description": "Подготовка учителей", "form": "очная", "budget_places": 20},
                {"name": "Экономика и бухгалтерский учёт", "description": "Подготовка бухгалтеров", "form": "очная", "budget_places": 20},
                {"name": "Право и социальное обеспечение", "description": "Подготовка юристов", "form": "очная", "budget_places": 15}
            ],
            "contact": {
                "address": "п. Палана, ул. Центральная, д. 1",
                "phone": "+7 (41543) 3-11-22",
                "email": "palan@edu.kamchatka.ru",
                "website": "https://palan41.ru"
            },
            "coordinates": {"lat": 59.0840, "lng": 159.9540},
            "employment_partners": ["Школы Корякского округа", "Администрации районов", "Социальные учреждения"],
            "extracurricular": ["Этнографический кружок", "Спортивные секции", "Волонтёрство"],
            "documents_required": ["Аттестат", "Паспорт", "СНИЛС", "Медицинская справка 086/У", "Фотографии 3x4"]
        },
        {
            "id": "kpt",
            "name": "КГПОБУ Камчатский промышленный техникум",
            "short_name": "КГПОБУ «КПТ»",
            "type": "spo",
            "director": "Директор техникума",
            "description": "Краевое государственное профессиональное образовательное бюджетное учреждение готовит кадры для рыбоперерабатывающей отрасли — основы экономики Камчатского края.",
            "logo": "https://kamchatkairo.ru/images/profnavigator/2025/kpt/logo.png",
            "image": "https://images.unsplash.com/photo-1498654896293-37aacf113fd9?w=800",
            "programs": [
                {"name": "Технология рыбы и рыбных продуктов", "description": "Переработка рыбы и морепродуктов", "form": "очная", "budget_places": 40},
                {"name": "Холодильная техника", "description": "Обслуживание холодильного оборудования", "form": "очная", "budget_places": 25},
                {"name": "Электротехника", "description": "Обслуживание электрооборудования", "form": "очная", "budget_places": 25}
            ],
            "contact": {
                "address": "г. Петропавловск-Камчатский, ул. Океанская, д. 88",
                "phone": "+7 (4152) 41-66-77",
                "email": "kpt@edu.kamchatka.ru",
                "website": "https://kpt41.ru"
            },
            "coordinates": {"lat": 53.0280, "lng": 158.6490},
            "employment_partners": ["Рыбоперерабатывающие заводы", "Порт", "Промышленные предприятия"],
            "extracurricular": ["Технический кружок", "Спортклуб", "Экологический отряд"],
            "documents_required": ["Аттестат", "Паспорт", "СНИЛС", "Медицинская справка 086/У", "Фотографии 3x4"]
        },
        {
            "id": "kppt",
            "name": "КГПОАУ Камчатский политехнический техникум",
            "short_name": "КГПОАУ «КПолТ»",
            "type": "spo",
            "director": "Директор техникума",
            "description": "Краевое государственное профессиональное образовательное автономное учреждение готовит IT-специалистов и программистов для цифровой экономики Камчатки.",
            "logo": "https://kamchatkairo.ru/images/profnavigator/2025/kppt/logo.png",
            "image": "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800",
            "programs": [
                {"name": "Информационные системы и программирование", "description": "Разработка ПО", "form": "очная", "budget_places": 50},
                {"name": "Компьютерные сети", "description": "Администрирование сетей", "form": "очная", "budget_places": 25},
                {"name": "Веб-дизайн", "description": "Создание веб-сайтов", "form": "очная", "budget_places": 25}
            ],
            "contact": {
                "address": "г. Петропавловск-Камчатский, пр. 50 лет Октября, д. 33",
                "phone": "+7 (4152) 42-44-55",
                "email": "kppt@edu.kamchatka.ru",
                "website": "https://kppt41.ru"
            },
            "coordinates": {"lat": 53.0210, "lng": 158.6630},
            "employment_partners": ["IT-компании", "Банки", "Госучреждения"],
            "extracurricular": ["IT-клуб", "Киберспорт", "Робототехника"],
            "documents_required": ["Аттестат", "Паспорт", "СНИЛС", "Медицинская справка 086/У", "Фотографии 3x4"]
        },
        {
            "id": "kkt",
            "name": "ПОЧУ Камчатский кооперативный техникум Камчатского краевого союза потребительских кооперативов",
            "short_name": "ПОЧУ «ККТ»",
            "type": "spo",
            "director": "Директор техникума",
            "description": "Профессиональное образовательное частное учреждение системы потребительской кооперации готовит специалистов в области торговли, экономики и права.",
            "logo": "https://kamchatkairo.ru/images/profnavigator/2025/kkt/logo.png",
            "image": "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=800",
            "programs": [
                {"name": "Коммерция", "description": "Организация торговли", "form": "очная", "budget_places": 25},
                {"name": "Экономика и бухгалтерский учёт", "description": "Подготовка бухгалтеров", "form": "очная", "budget_places": 25},
                {"name": "Право и организация социального обеспечения", "description": "Юридическая деятельность", "form": "очная", "budget_places": 25}
            ],
            "contact": {
                "address": "г. Петропавловск-Камчатский, ул. Ключевская, д. 11",
                "phone": "+7 (4152) 42-39-59",
                "email": "kkt@edu.kamchatka.ru",
                "website": "https://kkt41.ru"
            },
            "coordinates": {"lat": 53.0163, "lng": 158.6418},
            "employment_partners": ["Торговые сети", "Банки", "Юридические фирмы"],
            "extracurricular": ["Бизнес-клуб", "Волонтёрство", "Спорт"],
            "documents_required": ["Аттестат", "Паспорт", "СНИЛС", "Медицинская справка 086/У", "Фотографии 3x4"]
        },
        # Отделение СПО при КамчатГТУ
        {
            "id": "spo-kamgtu",
            "name": "Отделение СПО ФГБОУ ВО Камчатский государственный технический университет",
            "short_name": "Отделение СПО КамчатГТУ",
            "type": "spo",
            "director": "Руководитель отделения СПО",
            "description": "Отделение среднего профессионального образования при Камчатском государственном техническом университете готовит специалистов среднего звена технических специальностей.",
            "logo": "https://kamchatkairo.ru/images/profnavigator/2025/kamgtu/logo.png",
            "image": "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?w=800",
            "programs": [
                {"name": "Судовождение", "description": "Подготовка судоводителей", "form": "очная", "budget_places": 25},
                {"name": "Эксплуатация судовых энергетических установок", "description": "Судовые механики", "form": "очная", "budget_places": 25},
                {"name": "Технология рыбы и рыбных продуктов", "description": "Технологи рыбной отрасли", "form": "очная", "budget_places": 25}
            ],
            "contact": {
                "address": "г. Петропавловск-Камчатский, ул. Ключевская, д. 35",
                "phone": "+7 (4152) 42-17-00",
                "email": "spo@kamchatgtu.ru",
                "website": "https://kamchatgtu.ru"
            },
            "coordinates": {"lat": 53.0150, "lng": 158.6390},
            "employment_partners": ["Морские компании", "Рыболовецкие флотилии", "Рыбоперерабатывающие заводы"],
            "extracurricular": ["Морской клуб", "Спортклуб", "Студсовет"],
            "documents_required": ["Аттестат", "Паспорт", "СНИЛС", "Медицинская справка 086/У", "Фотографии 3x4"]
        },
        # Отделение СПО при КамГУ
        {
            "id": "spo-kamgu",
            "name": "Отделение СПО ФГБОУ ВО Камчатский государственный университет имени Витуса Беринга",
            "short_name": "Отделение СПО КамГУ",
            "type": "spo",
            "director": "Руководитель отделения СПО",
            "description": "Отделение среднего профессионального образования при Камчатском государственном университете имени Витуса Беринга готовит специалистов гуманитарного и педагогического профиля.",
            "logo": "https://kamchatkairo.ru/images/profnavigator/2025/kgu/logo.png",
            "image": "https://images.unsplash.com/photo-1562774053-701939374585?w=800",
            "programs": [
                {"name": "Преподавание в начальных классах", "description": "Подготовка учителей начальных классов", "form": "очная", "budget_places": 25},
                {"name": "Дошкольное образование", "description": "Подготовка воспитателей", "form": "очная", "budget_places": 25},
                {"name": "Информационные системы", "description": "IT-специалисты", "form": "очная", "budget_places": 25}
            ],
            "contact": {
                "address": "г. Петропавловск-Камчатский, ул. Пограничная, д. 4",
                "phone": "+7 (4152) 42-67-78",
                "email": "spo@kamgu.ru",
                "website": "https://kamgu.ru"
            },
            "coordinates": {"lat": 53.0170, "lng": 158.6540},
            "employment_partners": ["Школы Камчатки", "Детские сады", "IT-компании"],
            "extracurricular": ["Студенческий совет", "Волонтёрство", "Спортклуб"],
            "documents_required": ["Аттестат", "Паспорт", "СНИЛС", "Медицинская справка 086/У", "Фотографии 3x4"]
        },
        # IT-колледж
        {
            "id": "it-college",
            "name": "IT-колледж, отделение СПО ФГБОУ ВО Камчатский государственный технический университет",
            "short_name": "IT-колледж КамчатГТУ",
            "type": "spo",
            "director": "Руководитель IT-колледжа",
            "description": "IT-колледж при КамчатГТУ — современное образовательное подразделение, специализирующееся на подготовке высококвалифицированных специалистов в области информационных технологий.",
            "logo": "https://kamchatkairo.ru/images/profnavigator/2025/kamgtu/logo.png",
            "image": "https://images.unsplash.com/photo-1517694712202-14dd9538aa97?w=800",
            "programs": [
                {"name": "Информационные системы и программирование", "description": "Разработка программного обеспечения", "form": "очная", "budget_places": 50},
                {"name": "Компьютерные сети", "description": "Сетевое администрирование", "form": "очная", "budget_places": 25},
                {"name": "Информационная безопасность", "description": "Защита информации", "form": "очная", "budget_places": 25}
            ],
            "contact": {
                "address": "г. Петропавловск-Камчатский, ул. Ключевская, д. 35",
                "phone": "+7 (4152) 42-17-00",
                "email": "it-college@kamchatgtu.ru",
                "website": "https://kamchatgtu.ru/it-college"
            },
            "coordinates": {"lat": 53.0152, "lng": 158.6395},
            "employment_partners": ["IT-компании", "Банки", "Государственные учреждения", "Телеком-операторы"],
            "extracurricular": ["IT-клуб", "Хакатоны", "Киберспорт", "Робототехника"],
            "documents_required": ["Аттестат", "Паспорт", "СНИЛС", "Медицинская справка 086/У", "Фотографии 3x4"]
        },
        # ========== ВО (4 учреждения) ==========
        {
            "id": "kamgu",
            "name": "ФГБОУ ВО Камчатский государственный университет имени Витуса Беринга",
            "short_name": "ФГБОУ ВО «КамГУ»",
            "type": "vo",
            "director": "Ректор университета",
            "description": "Федеральное государственное бюджетное образовательное учреждение высшего образования — главный классический университет региона, готовящий педагогов, экономистов, филологов и IT-специалистов.",
            "logo": "https://kamchatkairo.ru/images/profnavigator/2025/kgu/logo.png",
            "image": "https://images.unsplash.com/photo-1562774053-701939374585?w=800",
            "programs": [
                {"name": "Педагогическое образование", "description": "Подготовка учителей", "form": "очная", "budget_places": 100, "cost": "от 150 000 руб./год"},
                {"name": "Экономика", "description": "Экономисты и финансисты", "form": "очная", "budget_places": 50, "cost": "от 160 000 руб./год"},
                {"name": "Прикладная информатика", "description": "IT-специалисты", "form": "очная", "budget_places": 50, "cost": "от 170 000 руб./год"},
                {"name": "Филология", "description": "Русский язык и литература", "form": "очная", "budget_places": 30, "cost": "от 145 000 руб./год"},
                {"name": "История", "description": "Историки и музееведы", "form": "очная", "budget_places": 25, "cost": "от 145 000 руб./год"},
                {"name": "Биология", "description": "Биологи и экологи", "form": "очная", "budget_places": 25, "cost": "от 155 000 руб./год"}
            ],
            "contact": {
                "address": "г. Петропавловск-Камчатский, ул. Пограничная, д. 4",
                "phone": "+7 (4152) 42-67-78",
                "email": "info@kamgu.ru",
                "website": "https://kamgu.ru"
            },
            "coordinates": {"lat": 53.0170, "lng": 158.6540},
            "employment_partners": ["Школы Камчатки", "Музеи", "IT-компании", "Научные институты"],
            "extracurricular": ["Студенческий совет", "КВН", "Научные конференции", "Волонтёрство"],
            "documents_required": ["Аттестат/Диплом", "Паспорт", "СНИЛС", "Результаты ЕГЭ", "Фотографии 3x4"]
        },
        {
            "id": "kamgtu",
            "name": "ФГБОУ ВО Камчатский государственный технический университет",
            "short_name": "ФГБОУ ВО «КамчатГТУ»",
            "type": "vo",
            "director": "Ректор университета",
            "description": "Федеральное государственное бюджетное образовательное учреждение высшего образования — ведущий технический вуз региона, готовящий инженеров для рыбной отрасли, судоходства, энергетики и IT.",
            "logo": "https://kamchatkairo.ru/images/profnavigator/2025/kamgtu/logo.png",
            "image": "https://images.unsplash.com/photo-1541339907198-e08756dedf3f?w=800",
            "programs": [
                {"name": "Судовождение", "description": "Управление морскими судами", "form": "очная", "budget_places": 50, "cost": "от 200 000 руб./год"},
                {"name": "Эксплуатация судовых энергетических установок", "description": "Судовые механики", "form": "очная", "budget_places": 40, "cost": "от 195 000 руб./год"},
                {"name": "Информатика и вычислительная техника", "description": "IT-инженеры", "form": "очная", "budget_places": 50, "cost": "от 180 000 руб./год"},
                {"name": "Электроэнергетика", "description": "Энергетики", "form": "очная", "budget_places": 30, "cost": "от 175 000 руб./год"},
                {"name": "Технология рыбы и рыбных продуктов", "description": "Технологи рыбной отрасли", "form": "очная", "budget_places": 40, "cost": "от 165 000 руб./год"}
            ],
            "contact": {
                "address": "г. Петропавловск-Камчатский, ул. Ключевская, д. 35",
                "phone": "+7 (4152) 42-17-00",
                "email": "info@kamchatgtu.ru",
                "website": "https://kamchatgtu.ru"
            },
            "coordinates": {"lat": 53.0150, "lng": 158.6390},
            "employment_partners": ["Морские компании", "Рыболовецкие флотилии", "Энергосбыт", "IT-фирмы"],
            "extracurricular": ["Морской клуб", "IT-лаборатория", "Спортклуб", "Студсовет"],
            "documents_required": ["Аттестат/Диплом", "Паспорт", "СНИЛС", "Результаты ЕГЭ", "Медицинская справка", "Фотографии 3x4"]
        },
        {
            "id": "dvf-vavt",
            "name": "ДВФ Всероссийская академия внешней торговли Министерства экономического развития Российской Федерации",
            "short_name": "ДВФ ВАВТ Минэкономразвития",
            "type": "vo",
            "director": "Директор филиала",
            "description": "Дальневосточный филиал Всероссийской академии внешней торговли готовит специалистов в области международной экономики, внешней торговли и юриспруденции.",
            "logo": "https://kamchatkairo.ru/images/profnavigator/2025/vavt/logo.png",
            "image": "https://images.unsplash.com/photo-1507679799987-c73779587ccf?w=800",
            "programs": [
                {"name": "Мировая экономика", "description": "Международные экономические отношения", "form": "очная", "budget_places": 15, "cost": "от 260 000 руб./год"},
                {"name": "Менеджмент", "description": "Управление международным бизнесом", "form": "очная", "budget_places": 20, "cost": "от 250 000 руб./год"},
                {"name": "Юриспруденция", "description": "Международное право", "form": "очная", "budget_places": 15, "cost": "от 289 000 руб./год"},
                {"name": "Торговое дело", "description": "Внешнеторговая деятельность", "form": "очная", "budget_places": 20, "cost": "от 240 000 руб./год"}
            ],
            "contact": {
                "address": "г. Петропавловск-Камчатский, ул. Вилюйская, д. 25",
                "phone": "+7 (4152) 42-01-47",
                "email": "dvf@vavt.ru",
                "website": "https://dvf-vavt.ru"
            },
            "coordinates": {"lat": 53.0220, "lng": 158.6570},
            "employment_partners": ["Внешторгбанк", "Таможенные органы", "Международные компании"],
            "extracurricular": ["Дипломатический клуб", "Модель ООН", "Языковые клубы"],
            "documents_required": ["Аттестат/Диплом", "Паспорт", "СНИЛС", "Результаты ЕГЭ", "Фотографии 3x4"]
        },
        {
            "id": "ruk",
            "name": "КФ АНО ОВО Центросоюза Российской Федерации Российский университет кооперации",
            "short_name": "КФ РУК",
            "type": "vo",
            "director": "Директор — Проценко Татьяна Георгиевна",
            "description": "Камчатский филиал автономной некоммерческой образовательной организации высшего образования Центросоюза РФ «Российский университет кооперации» готовит экономистов, юристов, менеджеров и специалистов в области туризма.",
            "logo": "https://kamchatkairo.ru/images/copp/ruk.png",
            "image": "https://images.unsplash.com/photo-1523240795612-9a054b0db644?w=800",
            "programs": [
                {"name": "Экономика", "description": "Экономика организаций", "form": "очная", "budget_places": 50, "cost": "169 200 руб./год"},
                {"name": "Юриспруденция", "description": "Гражданское и уголовное право", "form": "очная", "budget_places": 50, "cost": "169 200 руб./год"},
                {"name": "Менеджмент", "description": "Управление проектами", "form": "очно-заочная", "cost": "75 100 руб./год"},
                {"name": "Туризм", "description": "Организация туристской деятельности", "form": "очно-заочная", "cost": "90 400 руб./год"},
                {"name": "Таможенное дело", "description": "Таможенная логистика", "form": "очная", "budget_places": 50, "cost": "246 700 руб./год"}
            ],
            "contact": {
                "address": "г. Петропавловск-Камчатский, ул. Ключевская, д. 11",
                "phone": "+7 (4152) 42-39-59",
                "email": "pk@ruc.su",
                "website": "https://pk.ruc.su"
            },
            "coordinates": {"lat": 53.0163, "lng": 158.6418},
            "employment_partners": ["Торговые сети", "Туристические компании", "Таможенные органы", "Юридические фирмы"],
            "extracurricular": ["Студенческий совет", "Юнармия", "Волонтёры Победы", "Спортклуб «Вершина»"],
            "documents_required": ["Аттестат/Диплом", "Паспорт", "СНИЛС", "Результаты ЕГЭ", "Фотографии 3x4"]
        }
    ]
    
    await db.institutions.insert_many(institutions_data)
    return {"message": f"Successfully seeded {len(institutions_data)} institutions"}


# Include the router in the main app
app.include_router(api_router)

app.add_middleware(
    CORSMiddleware,
    allow_credentials=True,
    allow_origins=os.environ.get('CORS_ORIGINS', '*').split(','),
    allow_methods=["*"],
    allow_headers=["*"],
)

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

@app.on_event("shutdown")
async def shutdown_db_client():
    client.close()
